DROP USER vf_spmc_landing CASCADE;
DROP USER vf_spmc_staging CASCADE;
DROP USER vf_spmc_perf CASCADE;
DROP USER vf_spmc_ref CASCADE;
DROP USER vf_spmc_etl_error CASCADE;