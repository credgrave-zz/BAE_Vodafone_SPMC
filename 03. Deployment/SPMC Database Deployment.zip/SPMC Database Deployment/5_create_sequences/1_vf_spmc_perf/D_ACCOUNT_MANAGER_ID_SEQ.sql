--------------------------------------------------------
--  DDL for Sequence D_ACCOUNT_MANAGER_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "VF_SPMC_PERF"."D_ACCOUNT_MANAGER_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1041 CACHE 20 NOORDER  NOCYCLE ;
