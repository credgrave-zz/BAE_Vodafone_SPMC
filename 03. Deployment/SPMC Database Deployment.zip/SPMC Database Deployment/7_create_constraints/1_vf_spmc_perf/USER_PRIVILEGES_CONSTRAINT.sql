--------------------------------------------------------
--  Constraints for Table USER_PRIVILEGES
--------------------------------------------------------

  ALTER TABLE "USER_PRIVILEGES" MODIFY ("VALUE" NOT NULL ENABLE);
  ALTER TABLE "USER_PRIVILEGES" MODIFY ("PRIVILEGE_TYPE" NOT NULL ENABLE);
  ALTER TABLE "USER_PRIVILEGES" MODIFY ("USERNAME" NOT NULL ENABLE);
/
