--------------------------------------------------------
--  Constraints for Table F_KPI_PERFORMANCE_M
--------------------------------------------------------

  ALTER TABLE "F_KPI_PERFORMANCE_M" MODIFY ("LOCAL_MARKET_ID" NOT NULL ENABLE);
  ALTER TABLE "F_KPI_PERFORMANCE_M" MODIFY ("ACCOUNT_MANAGER_ID" NOT NULL ENABLE);
  ALTER TABLE "F_KPI_PERFORMANCE_M" MODIFY ("CALENDAR_MONTH_CD" NOT NULL ENABLE);
/
