GRANT ALTER ANY TABLE TO vf_spmc_ref;
GRANT ALTER ANY TABLE TO vf_spmc_landing;
GRANT ALTER ANY TABLE TO vf_spmc_staging;
GRANT ALTER ANY TABLE TO vf_spmc_perf;
GRANT ALTER ANY TABLE TO vf_spmc_etl_error;