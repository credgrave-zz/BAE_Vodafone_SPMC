-- Grant Create Database Link
GRANT CREATE DATABASE LINK TO vf_spmc_ref;
GRANT CREATE DATABASE LINK TO vf_spmc_landing;
GRANT CREATE DATABASE LINK TO vf_spmc_staging;
GRANT CREATE DATABASE LINK TO vf_spmc_perf;
GRANT CREATE DATABASE LINK TO vf_spmc_etl_error;