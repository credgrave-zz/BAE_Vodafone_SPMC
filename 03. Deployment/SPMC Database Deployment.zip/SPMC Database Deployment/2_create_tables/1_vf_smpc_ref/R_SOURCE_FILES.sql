--------------------------------------------------------
--  DDL for Table R_SOURCE_FILES
--------------------------------------------------------

  CREATE TABLE "VF_SPMC_REF"."R_SOURCE_FILES" 
   (	"SOURCE_FILE_ID" NUMBER, 
	"SOURCE_FILE_TYPE" VARCHAR2(20), 
	"SOURCE_FILE_NAME" VARCHAR2(50)
   ) ;
