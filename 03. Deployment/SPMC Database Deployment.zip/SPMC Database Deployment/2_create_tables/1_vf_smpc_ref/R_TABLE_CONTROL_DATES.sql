--------------------------------------------------------
--  DDL for Table R_TABLE_CONTROL_DATES
--------------------------------------------------------

  CREATE TABLE "VF_SPMC_REF"."R_TABLE_CONTROL_DATES" 
   (	"TABLE_NAME" VARCHAR2(30), 
	"COLUMN_NAME" VARCHAR2(30), 
	"CURRENT_FLAG" VARCHAR2(1), 
	"VALID_FROM" DATE, 
	"VALID_UNTIL" DATE
   ) ;
